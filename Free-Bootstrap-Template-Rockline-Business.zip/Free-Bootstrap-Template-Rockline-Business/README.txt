Note
====

Free Bootstrap Template  
Author URI: http://webthemez.com/

Rockline is a free bootstrap template based on the powerful BootStrap framework with HTML5 and CSS3. This is a single page website 
with a full screen header and image slider. This template looks great on a desktop and mobile resolution. This theme can be user in many ways like Business, corporate, portfolio, personal or any startup company. 


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Donate to remove the backline form the website.
Any help: webthemez@gmail.com

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	