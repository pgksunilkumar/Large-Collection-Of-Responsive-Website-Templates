Note
====

Line - Free App Landing Page Responsive Web Template

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/

Line is multipurpose landing page designed to showcase your web, mobile app, new products, modules, plugins and other. It is fully responsive and looks awesome on all types of devices (desktop, notebook, tablet and mobile).

This theme is built upon Bootstrap 3.2.0 framework. Clean and fast, easy to customize and use.



Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	