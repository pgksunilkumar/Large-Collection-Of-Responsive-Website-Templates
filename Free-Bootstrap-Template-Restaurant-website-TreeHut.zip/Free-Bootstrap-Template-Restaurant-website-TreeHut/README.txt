Note
====

Free Bootstrap Template  
Author URI: http://webthemez.com/

TreeHut is a one page Free HTML5 Bootstrap theme perfect for restaurants, cafes, bars coffee shops and catering companies.Build on the popular Twitter Bootstrap 3 responsive framework with HTML5 and CSS3. This template looks great on a desktop and mobile resolution its fully responsive. This theme is very easy to customize.


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Donate to remove the backline form the website.
Any help: webthemez@gmail.com

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	