Free Bootstrap Admin Template - Insight

Insight free bootstrap html5 admin template is a clean flat modern ready to use responsive admin dashboard template, based on Bootstrap v3.3.4, HTML5 and powered by jQuery, with amazing charts and graphs. This template is completely flexible and user friendly responsive supports all the browsers and looks clean on any device. Insight admin template is designed based on latest design standards, which fits to all kinds of requiments with number of useful plugins. The customizing of this admin template is very easy with comments inline and high quality HTML Code.


Key features
-------------
Twitter Bootstrap v3.3.4
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multipurpose Admin theme
Google Fonts Support
FontAwesome
UI Elements
Charts plugin
DataTables plugin
Smooth Scrolling 
Fully Customizable 


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com  
=> Framework : http://getbootstrap.com
=> webthemez@gmail.com
=> Donate and remove back link in the footer

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

 