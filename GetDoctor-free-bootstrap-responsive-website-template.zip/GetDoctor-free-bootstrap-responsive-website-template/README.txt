Doctor - Free Responsive Website Template
-------
Doctor is the best HTML5 theme designed for all the Doctors, Dentists and Health Consultants out there that need a professional yet modern looking website. This HTML template comes packed with medical features and enables them to interact easier. This is developed on HTML5, Bootstrap 3.2.0 and fully Responsive site template

Features :
--------
=> Twitter Bootstrap 3.2.0
=> Clean & Developer-friendly HTML5 and CSS3 code
=> 100% Responsive Layout Design
=> Multipurpose theme
=> Google Fonts Support
=> Font Awesome
=> Gallery Section Lightbox
=> Smooth Scrolling
=> Fully Customizable

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: All the images are used for DEMO purous only. we are not responsible for copyrights issues.


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
**Note: Please dont remove the backlink (Template by: webthemez.com) in the footer.
