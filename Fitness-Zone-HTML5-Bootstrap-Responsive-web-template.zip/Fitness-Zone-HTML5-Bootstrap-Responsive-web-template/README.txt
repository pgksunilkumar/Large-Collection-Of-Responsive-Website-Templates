Note
====

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/


Fitness zone theme is dedicated to create a gym, fitness, trainers or any sport related website. This theme is a one page website includes carousal, photo gallery and pricing plans etc. The layout is responsive and build upon latest bootstrap and html5. This template looks great on a desktop and mobile resolution.


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	