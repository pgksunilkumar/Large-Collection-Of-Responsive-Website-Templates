Interior-Design-Responsive-Website-Templates-StyleInn
-------

StyleInn bootstrap interior design website template is a well designed Responsive HTML5 template for interior design, decoration services, interior design portfolio, Real estate, Builders, Constructions, Architecture sites and many more. This template is build with latest technology Bootstrap, HTML5, CSS3 and jQuery. This theme is fully responsive fits in all type of devices and easy to use and also compatible with all major browsers. This theme has been provided with an nice responsive layer slider and easy to customize as per you requirements.

Features :
--------
=> Twitter Bootstrap 3.2.0
=> Clean & Developer-friendly HTML5 and CSS3 code
=> 100% Responsive Layout Design
=> Multipurpose theme
=> Google Fonts Support
=> Font Awesome
=> Gallery Section Lightbox
=> Smooth Scrolling
=> Fully Customizable
=> Camera Carousal

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: All the images are used for DEMO purous only. we are not responsible for copyrights issues.
=> http://imageion.net/

Important Note:
---------------
To remove backlink from the template, you need to donate to remove the backlink from the template.
Any question contact us: webthemez@gmail.com


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we�d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party

- If you wish to remove backlink from the template, you need to donate min USD $10 to remove backlink (credits) form the template

- If you have any question,feel free to contact us at webthemez@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.
