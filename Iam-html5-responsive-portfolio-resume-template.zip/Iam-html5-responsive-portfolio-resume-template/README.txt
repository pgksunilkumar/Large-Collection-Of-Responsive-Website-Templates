Bootstrap Responsive Template

I am HTML5 responsive portfolio resume template is clean multi purpose template suits a profissional designer or developer in IT industry, such as webdesigner, web developr, UX/UI Developer, Programmer�s portfolio. This is a responsive web template you can use for personal portfolio�s websites to showcase your work and CV or Resume template. This template is built on top of Bootstrap html5 css3 which give flexibilty to customeise the theme easly as per the user requirements. 


Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design
One Page
Multipurpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com


Important Note:
---------------
To remove backlink from the template, you need to donate to remove the backlink from the template.
Any question contact us: webthemez@gmail.com


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Note:
All images user here is for demo purpose only, we are not responsible for any copyrights.
