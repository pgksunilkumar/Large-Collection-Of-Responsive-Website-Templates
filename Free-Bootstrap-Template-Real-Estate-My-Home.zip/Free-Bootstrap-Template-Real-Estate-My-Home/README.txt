Note
====

Free Bootstrap Template  
Author URI: http://webthemez.com/

My Home template is for real estate builders theme especially for industry that need modern elegant and amazing looks. This template is developed on HTML5, Bootstrap 3.3.1 and fully Responsive site. This template suitable for Real estate, Builders, Constructions, Architecture sites. This theme is easy to customize as per you requirements. 


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Donate to remove the backline form the website.
Any help: webthemez@gmail.com

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	