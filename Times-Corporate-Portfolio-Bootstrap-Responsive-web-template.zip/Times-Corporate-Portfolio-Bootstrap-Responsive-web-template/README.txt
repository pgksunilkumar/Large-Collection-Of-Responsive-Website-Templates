Note
====

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/

Times is the modern HTML5 web template designed for all the Business, Corporate, Industries, Agency, personal portfolio and Consultants out there that need a professional yet modern looking website. This HTML template comes packed with features and enables them to interact easier. This is developed on HTML5, Bootstrap 3.2.0 and fully Responsive site template


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	