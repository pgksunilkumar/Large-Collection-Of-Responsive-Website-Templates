Note
====

alive-Responsive-Coming-Soon-Template

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/

alive is a minimal, responsive, business coming soon / landing page / one page HTML5 template based on Bootstrap 3.2.0. This theme is clean and fast, easy to customize multipurpose, includes Services and Contact form, 400+ Font Awesome icons, custom backgrounds and much more!



Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	