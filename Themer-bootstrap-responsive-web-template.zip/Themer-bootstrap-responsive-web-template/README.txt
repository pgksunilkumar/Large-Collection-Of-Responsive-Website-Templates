Note
====

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/
Description: This theme is a best responsive web template. It would be great for a corporate websites, business websites, personal blog, Portfolio and shopping
License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.	