<?php 
/*
 * A Design by W3layouts
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
 *
 */
include "app/config.php";
include "app/detect.php";

if ($page_name=='') {
	include $browser_t.'/index.html';
	}
elseif ($page_name=='index.html') {
	include $browser_t.'/index.html';
	}
elseif ($page_name=='bulk-domain-registration.html') {
	include $browser_t.'/bulk-domain-registration.html';
	}
elseif ($page_name=='bulk-domain-transfer.html') {
	include $browser_t.'/bulk-domain-transfer.html';
	}
elseif ($page_name=='create-account.html') {
	include $browser_t.'/create-account.html';
	}
elseif ($page_name=='domain-registration.html') {
	include $browser_t.'/domain-registration.html';
	}
elseif ($page_name=='email.html') {
	include $browser_t.'/email.html';
	}
elseif ($page_name=='free-with-every-domain.html') {
	include $browser_t.'/free-with-every-domain.html';
	}
elseif ($page_name=='idn-domain-registration.html') {
	include $browser_t.'/idn-domain-registration.html';
	}
elseif ($page_name=='linux-reseller-hosting.html') {
	include $browser_t.'/linux-reseller-hosting.html';
	}
elseif ($page_name=='login.html') {
	include $browser_t.'/login.html';
	}
elseif ($page_name=='name-suggestion-tool.html') {
	include $browser_t.'/name-suggestion-tool.html';
	}
elseif ($page_name=='ssl.html') {
	include $browser_t.'/ssl.html';
	}
elseif ($page_name=='support.html') {
	include $browser_t.'/support.html';
	}
elseif ($page_name=='transfer-your-domain.html') {
	include $browser_t.'/transfer-your-domain.html';
	}
elseif ($page_name=='view-domain-pricing.html') {
	include $browser_t.'/view-domain-pricing.html';
	}
elseif ($page_name=='website-builder.html') {
	include $browser_t.'/website-builder.html';
	}
elseif ($page_name=='whois-lookup.html') {
	include $browser_t.'/whois-lookup.html';
	}
elseif ($page_name=='windows-reseller-hosting.html') {
	include $browser_t.'/windows-reseller-hosting.html';
	}
elseif ($page_name=='404.html') {
	include $browser_t.'/404.html';
	}
elseif ($page_name=='contact-post.html') {
	include 'app/contact.php';
	}
else
	{
		include $browser_t.'/404.html';
	}

?>
