<?php 
/*
 * A Design by W3layouts
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
 *
 */
include "app/config.php";
include "app/detect.php";

if ($page_name=='') {
	include $browser_t.'/index.html';
	}
elseif ($page_name=='index.html') {
	include $browser_t.'/index.html';
	}
elseif ($page_name=='songs.html') {
	include $browser_t.'/songs.html';
	}
elseif ($page_name=='song-details.html') {
	include $browser_t.'/song-details.html';
	}
elseif ($page_name=='ringtones.html') {
	include $browser_t.'/ringtones.html';
	}
elseif ($page_name=='ring-details.html') {
	include $browser_t.'/ring-details.html';
	}
elseif ($page_name=='videos.html') {
	include $browser_t.'/videos.html';
	}
elseif ($page_name=='video-details.html') {
	include $browser_t.'/video-details.html';
	}
elseif ($page_name=='wallpapers.html') {
	include $browser_t.'/wallpapers.html';
	}
elseif ($page_name=='wall-details.html') {
	include $browser_t.'/wall-details.html';
	}
elseif ($page_name=='themes.html') {
	include $browser_t.'/themes.html';
	}
elseif ($page_name=='games.html') {
	include $browser_t.'/games.html';
	}
elseif ($page_name=='apps.html') {
	include $browser_t.'/apps.html';
	}
elseif ($page_name=='search.html') {
	include $browser_t.'/search.html';
	}
elseif ($page_name=='single-audio.html') {
	include $browser_t.'/single-audio.html';
	}
elseif ($page_name=='single-video.html') {
	include $browser_t.'/single-video.html';
	}
elseif ($page_name=='screensaver.html') {
	include $browser_t.'/screensaver.html';
	}
elseif ($page_name=='religious.html') {
	include $browser_t.'/religious.html';
	}
elseif ($page_name=='contact.html') {
	include $browser_t.'/contact.html';
	}
elseif ($page_name=='contact-post.html') {
	include 'app/contact.php';
	}
else
	{
		include $browser_t.'/404.html';
	}

?>
