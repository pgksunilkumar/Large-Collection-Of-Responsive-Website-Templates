Note
====

The Best Wedding Free Bootstrap Template

The Best wedding free bootstrap template is a clean and simple One Page HTML5 & CSS3 template that has a unique design touch with a jquery countdown plugin which makes the template more mordenized weddings theme. It is responsive works on mobile device and desktop. The template can be very easily customized as it has all its files very well structured with a clear comments in the source code. This theme can also fits for personal, portfolio and photography websites


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> For more free web themes: http://webthemez.com


To remove backlink from the site,
Please DONATE to us for our efforts


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we�d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party

- If you wish to remove backlink from the template, you need to donate min USD $10 to remove backlink (credits) form the template

- If you have any question,feel free to contact us at webthemez@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.

	