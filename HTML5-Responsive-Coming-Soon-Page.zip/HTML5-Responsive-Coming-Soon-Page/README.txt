Responsive Mobile First Web Template
------------------------------------
Author URI: http://webthemez.com/

Matrix - HTML5 Responsive Coming Soon Page:
Matrix HTML5 coming soon page is a modren flat look and feel clean theme, it is a responsive web compatable with multi devices, comes with unlimited background colors and patterns. The countdown is powered by a custom jQuery plugin, just you need to set you launching date in the script. This theme perfectily fit for your up coming projects.


Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Bootstrap
=> Multi device compatibility
=> Responsive design
=> jQuery Countdown plugin

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 
=> For more free web themes: http://webthemez.com

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

**Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).
