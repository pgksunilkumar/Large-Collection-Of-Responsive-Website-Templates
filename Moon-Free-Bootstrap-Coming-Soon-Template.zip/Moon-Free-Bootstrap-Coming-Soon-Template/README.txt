Note
====

Moon Free Bootstrap Coming Soon Template

Responsive, Bootstrap Mobile First Web Template 
Author URI: http://webthemez.com/


Moon is a clean bootstrap comming soon/under construction responsive template. Our coming soon template has a responsive slider, jQuery counter, contact section and navigation. This template is based on HTML5 latest bootstrap framework with mulit browser and device support.  


Credits
=======
Framework  http://getbootstrap.com
Images	(http://unsplash.com - CC0 licensed)
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

To remove backlink from the site,
Please DONATE to us for our efforts


Note: All the images used in this template is for demo use only, we are not responsible for any copyrights issue.

	