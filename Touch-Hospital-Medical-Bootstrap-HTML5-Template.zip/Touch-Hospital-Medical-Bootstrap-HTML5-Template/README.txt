﻿Responsive HTML5 Template

Touch Hospital Medical bootstrap HTML5 template is a clean modern designed Bootstrap template for a multi page lovers, This template fits in all types of requirements like the hospital, medical, clinic, veterinary, children care, portfolio and many more. This template is built using latest Bootstrap 3.2, html5 and css3 which is easy and simple to customise the theme as per your requirements. This template meet the latest requirement and it is fully responsive template fits in all devices with multi browser support. Start Download.

Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multi-purpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com, http://risewall.com/home-business-team-wallpapers.html
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com

Important Note:
---------------
To remove backlink from the template, you need to donate to remove the backlink from the template.
Any question contact us: webthemez@gmail.com


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we’d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party

- If you are a free member wish to remove backlink from the template, you need to donate min USD $10 to remove backlink (credits) form the template

- If you have any question,feel free to contact us at webthemez@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.
