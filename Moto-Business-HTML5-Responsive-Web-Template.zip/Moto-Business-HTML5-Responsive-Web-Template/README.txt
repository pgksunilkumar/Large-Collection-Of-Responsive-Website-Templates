﻿Free Responsive HTML5 Bootstrap Template

Moto business html5 responsive web template is a best flat clean and modern responsive HTML5 Bootstrap template for corporate consulting business profile. This theme has a elegant modern look, very easy to customize It’s provided with an nice responsive layer slider. This theme is fully responsive build on top of Bootstrap using HTML5 CSS3. Great for Corporate business, consulting office, Agency, portfolio and many more.  

Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multi-purpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> For more help: webthemez@gmail.com
=> Do not remove the back-link from site. If you want remove back-link please donate some bucks.

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

Note:
All images user here is for demo purpose only, we are not responsible for any copyrights.
