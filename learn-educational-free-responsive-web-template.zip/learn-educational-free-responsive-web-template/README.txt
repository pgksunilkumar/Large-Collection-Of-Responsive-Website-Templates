Learn - Educational Free Responsive Web Template
-------

LEARN is an HTML5 fully Responsive site template suitable for schools, colleges, Educational Institutes, Workshop and learning sites. It based on Bootstrap 3 and our theme is easy to customize and you can easily adapted and used for variety of similar niche websites.


Features :
--------
=> Easy to use, Heigh quality coded HTML5 and CSS3.
=> Multi device compatibility
=> Responsive design with bootstrap
=> premium quality template

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: we are not responsible for copyrights issues, please change asper your needs

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
**Note: Please dont remove the backlink (Template by: webthemez.com) in the footer.
