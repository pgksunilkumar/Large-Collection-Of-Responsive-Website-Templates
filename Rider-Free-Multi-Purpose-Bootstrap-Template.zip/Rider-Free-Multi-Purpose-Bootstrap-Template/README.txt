Bootstrap Template
-------
Rider free multi purpose bootstrap template is a clean and modern responsive HTML5 Bootstrap theme template for multi purpose use like corporate business consulting profile. This theme has a elegant modern look, very easy to customize It�s provided with an nice responsive layer slider. This theme is fully responsive build on top of Bootstrap using HTML5 CSS3.  Great for Corporate business, consulting office, Agency, portfolio and many more.
 
Features :
--------
=> Twitter Bootstrap 3.2.0
=> Clean & Developer-friendly HTML5 and CSS3 code
=> 100% Responsive Layout Design
=> Multipurpose theme
=> Google Fonts Support
=> Font Awesome
=> Gallery Section Lightbox
=> Smooth Scrolling
=> Fully Customizable
=> Camera Carousal

Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com 
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com
=> Image: All the images are used for DEMO purous only. we are not responsible for copyrights issues.
=> http://imageion.net/

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/
**Note: Please dont remove the backlink (Template by: webthemez.com) in the footer.
